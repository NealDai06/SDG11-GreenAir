# GreenAir Klang Valley - View layer (Java Swing)

Requires Java 17+ (uses records).

Compile and run the demo:

    javac -d out greenair/view/*.java
    java -cp out greenair.view.GreenAirApp

Demo logins: resident@demo.my, officer@demo.my, admin@demo.my (any password).
